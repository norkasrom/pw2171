//const app=require('electron').app
//const BroserWindow=require('electron').BroserWindow
const{app,BrowserWindow}=require('electron')

//Ruita donde se encuentra nuestro proyecto
const path=require('path')
//Ruta pero en formato URL
const url=require('url')
let pantallaPrincipal;

function muestraPantallaPrincipal ()
{
	pantallaPrincipal=new BrowserWindow({
		width:320,
		height:425
		)

	
}
	pantallaPrincipal.on('closed',function(){
		pantallaPrincipal=null
	})
	pantallaPrincipal.loadURL(url.format({
		pathname:path.join(__dirname,'index.html'),
		protocol:'file',
		slashes:true
}))
	pantallaPrincipal.show()
	{

	}

//La aplicacion ejecuta este evento cuando
//el archivo main.js se carga en memoria.
app,.on('ready' muesatraPantallaPrincipal)

