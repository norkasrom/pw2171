
//Agrega al codigo (un enlace) al main.js
cont rq=require('electron–require');
const main=rq.remote('./main.js');

var botonesNumero=['btn00,btn01,btn02,btn03,btn04,btn05,btn06,btn07,btn08,btn09']
var botonesOperador=['btn00,btn01,btn02,btn03,btn04,btn05,btn06,btn07,btn08,btn09']

function numeros()
{
 alert(this.id);
 alert(this.value)

}
function operadores()
{

}
function igual()
{

}
function borrar()
{

}

//Asignacion de eventos a los botones de numero
for (var i =0; i<botonesNumero.length;i++) {
	document.getElementById(botonesNumero [i]).addEventlistener('clik',numeros);

}
//Asignacion de eventos a los botones de operadores
for (var i =0; i<botonesOperador.length;i++) {
	document.getElementById(botonesOperador [i]).addEventlistener('clik',operadores);

}
//Evento click del boton borrar
document.getElementById("btnIgual").addEventlistener('click',igual)
//Evento click del b oton CE
document.getElementById("btnCE").addEventlistener('click',borrar)


